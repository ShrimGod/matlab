#ifndef __PERIODIC_CLUSTER__
#define __PERIODIC_CLUSTER__

#include <iostream>
#include "Frequency.hpp"
#include "Cluster.hpp"

struct PeriodicCluster : public Cluster {
    PeriodicCluster(){}
    PeriodicCluster(int cID): Cluster(cID) {}
    
    std::string classification;
    float freqMedian = -1.0f;
    float freqMean = -1.0f;
    float freqUncert = -1.0f;
    std::vector<std::shared_ptr<Frequency>> freqArray;

    // Rotation matrix elements for ellipse orientation
    float rotMat1;
    float rotMat2;
    float rotMat3;
    float rotMat4;

    void print(std::ostream& stream = std::cout) const {
        stream << "Cluster ID: " << clusterID << std::endl;
        stream << "Classification: " << classification << std::endl;
        stream << "Frequency Median: " << freqMedian << std::endl;
        stream << "freqUncert: " << freqUncert << std::endl;
        stream << "Encapsulating Ellipse:" << std::endl;
        stream << "x_c: " << x_c << std::endl;
        stream << "y_c: " << y_c << std::endl;
        stream << "majorRadius: " << majorRadius << std::endl;
        stream << "minorRadius: " << minorRadius << std::endl;
    }
};

#endif