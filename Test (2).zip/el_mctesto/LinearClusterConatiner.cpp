#include "LinearClusterContainer.hpp"

void LinearClusterContainer::printContainerStats() {
    std::set<uint64_t> uniqueKeys;
    for (const auto& pair : clusterMap) {
        uniqueKeys.insert(pair.first);
    }
    std::cout << "Number of Linear Cluster Time bins: " << uniqueKeys.size() << std::endl;
    for(const auto& key : uniqueKeys) {
        std::cout << "Time bin: " << key << " has " << clusterMap.count(key) << " linear clusters." << std::endl;
    }
}

void LinearClusterContainer::print(std::ostream& stream) const {
    for(auto i = clusterMap.begin(); i != clusterMap.end(); i++) {
        i->second->print(stream);
    }
}

void LinearClusterContainer::add(uint64_t timeBin, const LinearCluster& newCluster) {
    auto clusterPtr = std::make_shared<LinearCluster>(newCluster);
    updateTime(timeBin);
    clusterMap.insert({timeBin, clusterPtr});
}

std::vector<LinearClusterContainer::ClusterRef> LinearClusterContainer::find(const uint64_t timeBin) {
    std::vector<ClusterRef> matchingClusters;
    auto [begin, end] = clusterMap.equal_range(timeBin);
    for (auto it = begin; it != end; it++) {
        matchingClusters.emplace_back(std::ref(*it->second));
    }
    return matchingClusters;
}

void LinearClusterContainer::remove(uint64_t timeBin) {
    std::lock_guard<std::mutex> lock(lccLock);
    auto [begin, end] = clusterMap.equal_range(timeBin);
    for(auto i = begin; i != end; ) {
        i = clusterMap.erase(i);
    }
}