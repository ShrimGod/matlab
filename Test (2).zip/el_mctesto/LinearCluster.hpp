#ifndef _LINEAR_CLUSTER_
#define _LINEAR_CLUSTER_

#include <iostream>
#include <vector>
#include <memory>
#include <functional>
#include <set>

#include "Event.hpp"
#include "Cluster.hpp"

struct LinearCluster : public Cluster {
    LinearCluster() : Cluster() {}
    LinearCluster(int cID) : Cluster(cID) {}

    std::string classification; // Classification of the cluster
    using EventRef = std::reference_wrapper<const Event>;
    std::vector<EventRef> EventArray; // Array of event references associated with the cluster

    void print(std::ostream& stream = std::cout) {
        stream << "LinearCluster ID: " << clusterID << "\n"
               << "Classification: " << classification << "\n"
               << "x_c: " << x_c << "\n"
               << "y_c: " << y_c << "\n"
               << "Major Radius: " << majorRadius << "\n"
               << "Minor Radius: " << minorRadius << "\n";
    }
};

#endif