#ifndef ELLIPSE_ENCAPSULATION_HPP
#define ELLIPSE_ENCAPSULATION_HPP

#include "Options.hpp"
#include "pipelinemonitor.hpp"
#include "ClusterContainer.hpp"
#include "PeriodicCluster.hpp"
#include "LinearCluster.hpp"
#include "FrequencyContainer.hpp"

#include <vector>
#include <string>
#include <utility>
#include <tuple>
#include <cmath>
#include <sstream>
#include <set>

class EllipseEncapsulation {
public:
    // Constructor now uses templated ClusterContainer
    EllipseEncapsulation(std::shared_ptr<EBSOptions> o, 
                        std::shared_ptr<ClusterContainer<PeriodicCluster>> pcc,
                        std::shared_ptr<ClusterContainer<LinearCluster>> lcc = nullptr);
    
    ~EllipseEncapsulation() {
        std::cout << "EllipseEncapsulation destructor called." << std::endl;
    }

    void start(StageConnector connector);
    
    // Public method for testing
    void computeMVEEPublic(std::vector<std::pair<float, float>>& points, 
                          float& center_x, float& center_y,
                          float& major_radius, float& minor_radius,
                          float& rot1, float& rot2, float& rot3, float& rot4,
                          float tolerance) {
        computeMVEE(points, center_x, center_y, major_radius, minor_radius,
                   rot1, rot2, rot3, rot4, tolerance);
    }

private:
    std::shared_ptr<EBSOptions> options;
    std::shared_ptr<ClusterContainer<PeriodicCluster>> periodicClusterStream;
    std::shared_ptr<ClusterContainer<LinearCluster>> linearClusterStream;
    bool isPeriodicBranch;  // Determines which branch we're processing
    
    void computeMVEE(std::vector<std::pair<float, float>>& points, 
                     float& center_x, float& center_y, 
                     float& major_radius, float& minor_radius,
                     float& rot1, float& rot2, float& rot3, float& rot4, 
                     float tolerance);
    
    // Process periodic clusters
    void encapsulatePeriodicClusters(const std::vector<std::reference_wrapper<PeriodicCluster>>& clusterVector);
    
    // Process linear clusters
    void encapsulateLinearClusters(const std::vector<std::reference_wrapper<LinearCluster>>& clusterVector);
    
    // Extract points from different cluster types
    std::vector<std::pair<float, float>> extractPointsFromPeriodicCluster(const PeriodicCluster& cluster);
    std::vector<std::pair<float, float>> extractPointsFromLinearCluster(const LinearCluster& cluster);
};

#endif