#include <iostream>
#include <vector>
#include <cmath>
#include <memory>
#include <cassert>
#include <algorithm>
#include <random>

#include "ellipse_encapsulation.hpp"
#include "Options.hpp"
#include "PeriodicClusterContainer.hpp"
#include "LinearClusterContainer.hpp"
#include "Event.hpp"
#include "Frequency.hpp"

// Helper function to create test options
std::shared_ptr<EBSOptions> createTestOptions() {
    auto options = std::make_shared<EBSOptions>();
    options->periodic_ellipse_enc.tol = 0.001f;
    options->nonperiodic_ellipse_enc.tol = 0.001f;
    options->freq.time_bin_duration = 100000;
    return options;
}

// Helper function to check if a point is inside an ellipse
bool isPointInEllipse(float px, float py, float cx, float cy, 
                      float major_r, float minor_r, 
                      float rot1, float rot2, float rot3, float rot4) {
    // Transform point to ellipse coordinate system
    float dx = px - cx;
    float dy = py - cy;
    
    // Apply inverse rotation
    float tx = rot1 * dx + rot3 * dy;  // rot3 is actually -rot2 for inverse
    float ty = rot2 * dx + rot4 * dy;  // rot4 is actually rot1 for inverse
    
    // Check if point is inside unit ellipse
    float val = (tx * tx) / (major_r * major_r) + (ty * ty) / (minor_r * minor_r);
    return val <= 1.0001f; // Small tolerance for numerical errors
}

// Test 1: Degenerate cases
bool testDegenerateCases() {
    std::cout << "\n=== Test 1: Degenerate Cases ===" << std::endl;
    
    auto options = createTestOptions();
    auto periodicContainer = std::make_shared<PeriodicClusterContainer>();
    auto linearContainer = std::make_shared<LinearClusterContainer>();
    
    EllipseEncapsulation encapsulator(options, periodicContainer, linearContainer);
    
    // Test 1a: Empty point set
    {
        std::vector<std::pair<float, float>> points;
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        bool passed = (cx == 0.0f && cy == 0.0f && major_r == 1.0f && minor_r == 1.0f);
        std::cout << "Empty point set: " << (passed ? "PASSED" : "FAILED") << std::endl;
        if (!passed) return false;
    }
    
    // Test 1b: Single point
    {
        std::vector<std::pair<float, float>> points = {{5.0f, 3.0f}};
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        bool passed = (std::abs(cx - 5.0f) < 0.01f && std::abs(cy - 3.0f) < 0.01f);
        std::cout << "Single point: center=(" << cx << "," << cy << ") " 
                  << (passed ? "PASSED" : "FAILED") << std::endl;
        if (!passed) return false;
    }
    
    // Test 1c: Two points (creates line)
    {
        std::vector<std::pair<float, float>> points = {{0.0f, 0.0f}, {4.0f, 3.0f}};
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        float expected_cx = 2.0f;
        float expected_cy = 1.5f;
        float expected_major = std::sqrt(4*4 + 3*3) / 2.0f + 1.0f;
        
        bool passed = (std::abs(cx - expected_cx) < 0.01f && 
                      std::abs(cy - expected_cy) < 0.01f &&
                      std::abs(major_r - expected_major) < 0.1f &&
                      minor_r == 1.0f);
        
        std::cout << "Two points: center=(" << cx << "," << cy << "), radii=(" 
                  << major_r << "," << minor_r << ") " 
                  << (passed ? "PASSED" : "FAILED") << std::endl;
        if (!passed) return false;
    }
    
    return true;
}

// Test 2: Known shapes
bool testKnownShapes() {
    std::cout << "\n=== Test 2: Known Shapes ===" << std::endl;
    
    auto options = createTestOptions();
    auto periodicContainer = std::make_shared<PeriodicClusterContainer>();
    auto linearContainer = std::make_shared<LinearClusterContainer>();
    
    EllipseEncapsulation encapsulator(options, periodicContainer, linearContainer);
    
    // Test 2a: Circle of points
    {
        std::vector<std::pair<float, float>> points;
        const int n_points = 20;
        const float radius = 10.0f;
        const float center_x = 50.0f;
        const float center_y = 50.0f;
        
        for (int i = 0; i < n_points; i++) {
            float angle = 2.0f * M_PI * i / n_points;
            points.emplace_back(center_x + radius * std::cos(angle), 
                               center_y + radius * std::sin(angle));
        }
        
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        bool center_correct = (std::abs(cx - center_x) < 0.1f && std::abs(cy - center_y) < 0.1f);
        bool radii_correct = (std::abs(major_r - radius) < 0.5f && std::abs(minor_r - radius) < 0.5f);
        bool circular = std::abs(major_r - minor_r) < 0.5f;
        
        std::cout << "Circle: center=(" << cx << "," << cy << "), radii=(" 
                  << major_r << "," << minor_r << ")" << std::endl;
        std::cout << "  Center correct: " << (center_correct ? "YES" : "NO") << std::endl;
        std::cout << "  Radii correct: " << (radii_correct ? "YES" : "NO") << std::endl;
        std::cout << "  Is circular: " << (circular ? "YES" : "NO") << std::endl;
        
        if (!center_correct || !radii_correct || !circular) return false;
    }
    
    // Test 2b: Axis-aligned rectangle
    {
        std::vector<std::pair<float, float>> points = {
            {10.0f, 20.0f}, {40.0f, 20.0f}, {40.0f, 30.0f}, {10.0f, 30.0f}
        };
        
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        float expected_cx = 25.0f;
        float expected_cy = 25.0f;
        float expected_major = 15.0f;  // Half width
        float expected_minor = 5.0f;   // Half height
        
        bool center_correct = (std::abs(cx - expected_cx) < 0.1f && std::abs(cy - expected_cy) < 0.1f);
        bool size_correct = (std::abs(major_r - expected_major) < 1.0f && 
                            std::abs(minor_r - expected_minor) < 1.0f);
        
        std::cout << "Rectangle: center=(" << cx << "," << cy << "), radii=(" 
                  << major_r << "," << minor_r << ")" << std::endl;
        std::cout << "  Center correct: " << (center_correct ? "YES" : "NO") << std::endl;
        std::cout << "  Size correct: " << (size_correct ? "YES" : "NO") << std::endl;
        
        if (!center_correct || !size_correct) return false;
    }
    
    // Test 2c: Ellipse of points (rotated)
    {
        std::vector<std::pair<float, float>> points;
        const int n_points = 30;
        const float a = 20.0f;  // Major semi-axis
        const float b = 10.0f;  // Minor semi-axis
        const float rotation = M_PI / 4.0f;  // 45 degrees
        const float cx_true = 100.0f;
        const float cy_true = 100.0f;
        
        for (int i = 0; i < n_points; i++) {
            float angle = 2.0f * M_PI * i / n_points;
            float x_ellipse = a * std::cos(angle);
            float y_ellipse = b * std::sin(angle);
            
            // Rotate
            float x_rot = x_ellipse * std::cos(rotation) - y_ellipse * std::sin(rotation);
            float y_rot = x_ellipse * std::sin(rotation) + y_ellipse * std::cos(rotation);
            
            points.emplace_back(cx_true + x_rot, cy_true + y_rot);
        }
        
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        bool center_correct = (std::abs(cx - cx_true) < 0.5f && std::abs(cy - cy_true) < 0.5f);
        bool size_correct = (std::abs(major_r - a) < 1.0f && std::abs(minor_r - b) < 1.0f);
        
        std::cout << "Rotated ellipse: center=(" << cx << "," << cy << "), radii=(" 
                  << major_r << "," << minor_r << ")" << std::endl;
        std::cout << "  Center correct: " << (center_correct ? "YES" : "NO") << std::endl;
        std::cout << "  Size correct: " << (size_correct ? "YES" : "NO") << std::endl;
        
        if (!center_correct || !size_correct) return false;
    }
    
    return true;
}

// Test 3: Edge cases
bool testEdgeCases() {
    std::cout << "\n=== Test 3: Edge Cases ===" << std::endl;
    
    auto options = createTestOptions();
    auto periodicContainer = std::make_shared<PeriodicClusterContainer>();
    auto linearContainer = std::make_shared<LinearClusterContainer>();
    
    EllipseEncapsulation encapsulator(options, periodicContainer, linearContainer);
    
    // Test 3a: Collinear points
    {
        std::vector<std::pair<float, float>> points;
        for (int i = 0; i < 10; i++) {
            points.emplace_back(i * 10.0f, i * 5.0f);  // Points on line y = 0.5x
        }
        
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        // Should create thin ellipse along the line
        bool is_thin = (minor_r < major_r * 0.1f);
        
        std::cout << "Collinear points: radii=(" << major_r << "," << minor_r << ")" << std::endl;
        std::cout << "  Creates thin ellipse: " << (is_thin ? "YES" : "NO") << std::endl;
        
        // Note: This might create numerical issues, so we're lenient
    }
    
    // Test 3b: Very close points (numerical stability)
    {
        std::vector<std::pair<float, float>> points = {
            {100.0f, 100.0f}, {100.001f, 100.0f}, {100.0f, 100.001f}, {100.001f, 100.001f}
        };
        
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        
        try {
            encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                           rot1, rot2, rot3, rot4, 0.001f);
            
            bool center_stable = (std::abs(cx - 100.0005f) < 0.01f && 
                                 std::abs(cy - 100.0005f) < 0.01f);
            
            std::cout << "Very close points: center=(" << cx << "," << cy << ")" << std::endl;
            std::cout << "  Numerically stable: " << (center_stable ? "YES" : "NO") << std::endl;
            
        } catch (...) {
            std::cout << "Very close points: Exception thrown (numerical instability)" << std::endl;
            return false;
        }
    }
    
    // Test 3c: Large coordinate values
    {
        std::vector<std::pair<float, float>> points = {
            {10000.0f, 20000.0f}, {10100.0f, 20000.0f}, 
            {10100.0f, 20100.0f}, {10000.0f, 20100.0f}
        };
        
        float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
        encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                       rot1, rot2, rot3, rot4, 0.001f);
        
        bool reasonable = (cx > 9000 && cx < 11000 && cy > 19000 && cy < 21000);
        
        std::cout << "Large coordinates: center=(" << cx << "," << cy << ")" << std::endl;
        std::cout << "  Handles large values: " << (reasonable ? "YES" : "NO") << std::endl;
        
        if (!reasonable) return false;
    }
    
    return true;
}

// Test 4: Cluster differentiation
bool testClusterDifferentiation() {
    std::cout << "\n=== Test 4: Cluster Type Differentiation ===" << std::endl;
    
    auto options = createTestOptions();
    auto periodicContainer = std::make_shared<PeriodicClusterContainer>();
    auto linearContainer = std::make_shared<LinearClusterContainer>();
    
    uint64_t timeBin = 100000;
    
    // Create a periodic cluster
    PeriodicCluster pCluster;
    pCluster.clusterID = 1;
    pCluster.classification = "blinking";
    pCluster.freqMean = 10.0f;
    pCluster.freqMedian = 10.0f;
    
    // Add frequency points in a circular pattern
    for (int i = 0; i < 8; i++) {
        float angle = 2.0f * M_PI * i / 8;
        auto freq = std::make_shared<Frequency>();
        freq->x = static_cast<int>(100 + 10 * std::cos(angle));
        freq->y = static_cast<int>(100 + 10 * std::sin(angle));
        freq->f = 10.0f;
        freq->phase = angle;
        pCluster.freqArray.push_back(freq);
    }
    
    periodicContainer->add(timeBin, pCluster);
    
    // Create a linear cluster
    LinearCluster lCluster;
    lCluster.clusterID = 2;
    lCluster.classification = "moving";
    
    // Add events along a diagonal line
    for (int i = 0; i < 10; i++) {
        Event e;
        e.x = 200 + i * 5;
        e.y = 200 + i * 5;
        e.t = 1000 + i * 100;
        e.p = (i % 2 == 0);
        lCluster.EventArray.emplace_back(e);
    }
    
    linearContainer->add(timeBin, lCluster);
    
    // Test periodic branch
    {
        EllipseEncapsulation periodicEncapsulator(options, periodicContainer);
        auto pClusters = periodicContainer->find(timeBin);
        
        if (!pClusters.empty()) {
            periodicEncapsulator.encapsulatePeriodicClustersPublic(pClusters);
            
            const auto& processed = pClusters[0].get();
            bool hasEllipse = (processed.x_c != -1 && processed.y_c != -1);
            
            std::cout << "Periodic cluster processing: " << (hasEllipse ? "PASSED" : "FAILED") << std::endl;
            std::cout << "  Ellipse center: (" << processed.x_c << "," << processed.y_c << ")" << std::endl;
            std::cout << "  Ellipse radii: (" << processed.majorRadius << "," << processed.minorRadius << ")" << std::endl;
            
            if (!hasEllipse) return false;
        }
    }
    
    // Test non-periodic branch
    {
        EllipseEncapsulation linearEncapsulator(options, periodicContainer, linearContainer);
        auto lClusters = linearContainer->find(timeBin);
        
        if (!lClusters.empty()) {
            linearEncapsulator.encapsulateLinearClustersPublic(lClusters);
            
            const auto& processed = lClusters[0].get();
            bool hasEllipse = (processed.x_c != -1 && processed.y_c != -1);
            
            std::cout << "Linear cluster processing: " << (hasEllipse ? "PASSED" : "FAILED") << std::endl;
            std::cout << "  Ellipse center: (" << processed.x_c << "," << processed.y_c << ")" << std::endl;
            std::cout << "  Ellipse radii: (" << processed.majorRadius << "," << processed.minorRadius << ")" << std::endl;
            
            if (!hasEllipse) return false;
        }
    }
    
    return true;
}

// Test 5: MVEE containment property
bool testMVEEContainment() {
    std::cout << "\n=== Test 5: MVEE Containment Property ===" << std::endl;
    
    auto options = createTestOptions();
    auto periodicContainer = std::make_shared<PeriodicClusterContainer>();
    auto linearContainer = std::make_shared<LinearClusterContainer>();
    
    EllipseEncapsulation encapsulator(options, periodicContainer, linearContainer);
    
    // Generate random points
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis_x(0.0, 200.0);
    std::uniform_real_distribution<> dis_y(0.0, 200.0);
    
    std::vector<std::pair<float, float>> points;
    const int n_points = 50;
    
    for (int i = 0; i < n_points; i++) {
        points.emplace_back(dis_x(gen), dis_y(gen));
    }
    
    float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
    encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                   rot1, rot2, rot3, rot4, 0.001f);
    
    // Check that all points are contained
    int contained = 0;
    for (const auto& p : points) {
        if (isPointInEllipse(p.first, p.second, cx, cy, major_r, minor_r, 
                            rot1, rot2, rot3, rot4)) {
            contained++;
        }
    }
    
    bool all_contained = (contained == n_points);
    
    std::cout << "Random points: " << contained << "/" << n_points << " contained" << std::endl;
    std::cout << "  MVEE contains all points: " << (all_contained ? "YES" : "NO") << std::endl;
    
    return all_contained;
}

// Test 6: Performance with many points
bool testPerformance() {
    std::cout << "\n=== Test 6: Performance Test ===" << std::endl;
    
    auto options = createTestOptions();
    auto periodicContainer = std::make_shared<PeriodicClusterContainer>();
    auto linearContainer = std::make_shared<LinearClusterContainer>();
    
    EllipseEncapsulation encapsulator(options, periodicContainer, linearContainer);
    
    // Create a large cluster
    std::vector<std::pair<float, float>> points;
    const int n_points = 1000;
    
    // Generate points in a noisy elliptical distribution
    std::random_device rd;
    std::mt19937 gen(rd());
    std::normal_distribution<> noise(0.0, 1.0);
    
    for (int i = 0; i < n_points; i++) {
        float angle = 2.0f * M_PI * i / n_points;
        float r = 50.0f + 5.0f * noise(gen);
        float x = 500.0f + r * std::cos(angle);
        float y = 500.0f + r * 0.5f * std::sin(angle);  // Elliptical
        points.emplace_back(x, y);
    }
    
    auto start_time = std::chrono::high_resolution_clock::now();
    
    float cx, cy, major_r, minor_r, rot1, rot2, rot3, rot4;
    encapsulator.computeMVEEPublic(points, cx, cy, major_r, minor_r, 
                                   rot1, rot2, rot3, rot4, 0.001f);
    
    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
    
    std::cout << "Processing " << n_points << " points took " << duration.count() << " ms" << std::endl;
    std::cout << "  Center: (" << cx << "," << cy << ")" << std::endl;
    std::cout << "  Radii: (" << major_r << "," << minor_r << ")" << std::endl;
    
    bool reasonable_time = (duration.count() < 5000);  // Should complete in < 5 seconds
    std::cout << "  Reasonable computation time: " << (reasonable_time ? "YES" : "NO") << std::endl;
    
    return reasonable_time;
}

int main() {
    std::cout << "=== Ellipse Encapsulation Test Suite ===" << std::endl;
    std::cout << "Testing Minimum Volume Enclosing Ellipse (MVEE) algorithm\n" << std::endl;
    
    int passed = 0;
    int total = 6;
    
    // Run all tests
    if (testDegenerateCases()) passed++;
    if (testKnownShapes()) passed++;
    if (testEdgeCases()) passed++;
    if (testClusterDifferentiation()) passed++;
    if (testMVEEContainment()) passed++;
    if (testPerformance()) passed++;
    
    // Summary
    std::cout << "\n=== Test Summary ===" << std::endl;
    std::cout << "Tests passed: " << passed << "/" << total << std::endl;
    
    if (passed == total) {
        std::cout << "All tests PASSED!" << std::endl;
        return 0;
    } else {
        std::cout << "Some tests FAILED!" << std::endl;
        return 1;
    }
}