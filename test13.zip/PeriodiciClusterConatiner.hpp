#ifndef __PERIODIC_CLUSTER_CONTAINER__
#define __PERIODIC_CLUSTER_CONTAINER__

#include <map>
#include <set>

#include "EBSDataContainer.hpp"
#include "PeriodicCluster.hpp"

class PeriodicClusterContainer : public EBSDataContainer {
    private:
        std::multimap<uint64_t,std::shared_ptr<PeriodicCluster>> clusterMap;
        using ClusterRef = std::reference_wrapper<PeriodicCluster>;
        std::mutex pccLock;
    public:
        void printContainerStats() override;
        void print(std::ostream& stream = std::cout);
        int size() {return clusterMap.size();}
        int count(uint64_t key){return clusterMap.count(key);}
        void add(uint64_t timeBin,const PeriodicCluster &newCluster);
        std::vector<ClusterRef> find(const uint64_t timeBin);
        void remove(uint64_t timeBin);

   
};

#endif