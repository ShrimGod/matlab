#ifndef __LINEAR_CLUSTER_CONTAINER__
#define __LINEAR_CLUSTER_CONTAINER__

#include <map>
#include <set>
#include <memory>
#include <mutex>

#include "EBSDataContainer.hpp"
#include "LinearCluster.hpp"

class LinearClusterContainer : public EBSDataContainer {
    private:
        std::multimap<uint64_t, std::shared_ptr<LinearCluster>> clusterMap;
        using ClusterRef = std::reference_wrapper<const LinearCluster>;
        std::mutex lccLock;
        
    public:
        void printContainerStats() override;
        void print(std::ostream& stream = std::cout);
        int size() { return clusterMap.size(); }
        int count(uint64_t key) { return clusterMap.count(key); }
        void add(uint64_t timeBin, const LinearCluster& newCluster);
        std::vector<ClusterRef> find(const uint64_t timeBin);
        void remove(uint64_t timeBin);
};

#endif